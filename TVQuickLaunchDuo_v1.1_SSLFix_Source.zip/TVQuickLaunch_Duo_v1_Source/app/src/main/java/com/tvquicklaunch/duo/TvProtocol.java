package com.tvquicklaunch.duo;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import java.util.Locale;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;

/** The Remote v2 pairing and app-link subset. All methods use a worker thread. */
final class TvProtocol {
    static final int PAIR_PORT = 6467;
    static final int REMOTE_PORT = 6466;
    private final Context context;
    private SSLSocket pairingSocket;
    private Certificate pairingPeer;
    private String pendingHost;

    TvProtocol(Context context) {
        this.context = context.getApplicationContext();
        // v1 used a signing-restricted AndroidKeyStore RSA identity. v2 uses
        // a normal PKCS#12 TLS client certificate; re-pair once after upgrade.
        SharedPreferences prefs = preferences();
        if (prefs.getInt("client_identity_version", 1) < 2) {
            prefs.edit().putInt("client_identity_version", 2)
                    .remove("paired_host").remove("server_cert_sha256").apply();
        }
    }

    static String fingerprint(Certificate certificate) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(certificate.getEncoded());
        StringBuilder result = new StringBuilder(hash.length * 2);
        for (byte b : hash) result.append(String.format(Locale.ROOT, "%02x", b & 255));
        return result.toString();
    }

    private SharedPreferences preferences() {
        return context.getSharedPreferences("tv_settings", Context.MODE_PRIVATE);
    }

    /** TLS client identity persisted in the app-private directory. */
    private KeyStore clientKeys() throws Exception {
        return ClientIdentity.loadOrCreate(context.getFilesDir());
    }

    private static final class PeerTrust implements X509TrustManager {
        X509Certificate peer;
        @Override public void checkClientTrusted(X509Certificate[] chain, String authType) {}
        @Override public void checkServerTrusted(X509Certificate[] chain, String authType) {
            if (chain != null && chain.length > 0) peer = chain[0];
        }
        @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }

    private static final class Connection {
        final SSLSocket socket;
        final X509Certificate server;
        Connection(SSLSocket socket, X509Certificate server) { this.socket = socket; this.server = server; }
    }

    /** Pairing authenticates the server via the displayed challenge; later sessions pin that cert. */
    private Connection connect(String address, int port) throws Exception {
        KeyManagerFactory km = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        km.init(clientKeys(), ClientIdentity.password());
        PeerTrust trust = new PeerTrust();
        SSLContext ssl = SSLContext.getInstance("TLS");
        ssl.init(km.getKeyManagers(), new javax.net.ssl.TrustManager[]{trust}, new SecureRandom());
        SSLSocket socket = (SSLSocket) ssl.getSocketFactory().createSocket();
        try {
            socket.connect(new InetSocketAddress(address, port), 4500);
            socket.setSoTimeout(9000);
            socket.startHandshake();
            X509Certificate cert = trust.peer;
            if (cert == null) {
                Certificate[] chain = socket.getSession().getPeerCertificates();
                cert = (X509Certificate) chain[0];
            }
            if (port == REMOTE_PORT) {
                String pinned = preferences().getString("server_cert_sha256", "");
                if (pinned.isEmpty() || !pinned.equals(fingerprint(cert)))
                    throw new SecurityException("电视配对身份不匹配，请重新配对");
            }
            return new Connection(socket, cert);
        } catch (Exception error) {
            try { socket.close(); } catch (Exception ignored) {}
            throw error;
        }
    }

    private static Proto.Writer pairingEnvelope(int child, Proto.Writer nested) {
        return new Proto.Writer().number(1, 2).number(2, 200).message(child, nested);
    }

    private static void assertPairStatus(Proto.Message response) throws IOException {
        long status = response.number(2, 200);
        if (status != 200) throw new IOException("电视拒绝配对，状态码 " + status);
    }

    /** First half of PIN pairing; returns once TV has displayed the PIN. */
    void beginPairing(String host) throws Exception {
        discardPairing();
        Connection conn = connect(host, PAIR_PORT);
        pairingSocket = conn.socket;
        pairingPeer = conn.server;
        pendingHost = host;
        try {
            InputStream input = conn.socket.getInputStream();
            OutputStream output = conn.socket.getOutputStream();
            Proto.send(output, pairingEnvelope(10,
                    new Proto.Writer().string(1, "tvquicklaunch").string(2, "TV Quick Launch Duo")));
            for (int n = 0; n < 8; n++) {
                Proto.Message response = Proto.receive(input);
                assertPairStatus(response);
                if (response.has(11)) {
                    Proto.Writer options = new Proto.Writer()
                            .message(1, new Proto.Writer().number(1, 3).number(2, 6))
                            .number(3, 1);
                    Proto.send(output, pairingEnvelope(20, options));
                } else if (response.has(20)) {
                    Proto.Writer configuration = new Proto.Writer()
                            .message(1, new Proto.Writer().number(1, 3).number(2, 6))
                            .number(2, 1);
                    Proto.send(output, pairingEnvelope(30, configuration));
                } else if (response.has(31)) {
                    return;
                } else {
                    throw new IOException("电视返回了未知配对步骤");
                }
            }
            throw new IOException("电视配对超时");
        } catch (Exception error) {
            discardPairing();
            throw error;
        }
    }

    private static byte[] unsigned(BigInteger integer) {
        byte[] bytes = integer.toByteArray();
        return bytes.length > 1 && bytes[0] == 0 ? Arrays.copyOfRange(bytes, 1, bytes.length) : bytes;
    }

    private byte[] pairingSecret(String text) throws Exception {
        if (pairingPeer == null || pairingSocket == null) throw new IllegalStateException("请先开始配对");
        String code = text.trim().toUpperCase(Locale.ROOT);
        if (!code.matches("[0-9A-F]{6}"))
            throw new IllegalArgumentException("请输入电视显示的 6 位十六进制配对码（0-9、A-F）");
        RSAPublicKey localKey = (RSAPublicKey) clientKeys().getCertificate(ClientIdentity.alias()).getPublicKey();
        RSAPublicKey tvKey = (RSAPublicKey) pairingPeer.getPublicKey();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update(unsigned(localKey.getModulus()));
        digest.update(unsigned(localKey.getPublicExponent()));
        digest.update(unsigned(tvKey.getModulus()));
        digest.update(unsigned(tvKey.getPublicExponent()));
        byte[] codeTail = new byte[2];
        for (int n = 0; n < 2; n++) codeTail[n] = (byte) Integer.parseInt(code.substring(2 + n * 2, 4 + n * 2), 16);
        digest.update(codeTail);
        byte[] secret = digest.digest();
        if ((secret[0] & 255) != Integer.parseInt(code.substring(0, 2), 16))
            throw new IllegalArgumentException("配对码与电视不匹配，请检查电视上的字符");
        return secret;
    }

    /** Second half; saves TV identity only after it acknowledges the PIN. */
    void completePairing(String code) throws Exception {
        byte[] digest = pairingSecret(code);  // If mistyped, preserve the session for retry.
        try {
            Proto.send(pairingSocket.getOutputStream(), pairingEnvelope(40,
                    new Proto.Writer().bytes(1, digest)));
            Proto.Message response = Proto.receive(pairingSocket.getInputStream());
            assertPairStatus(response);
            if (!response.has(41)) throw new IOException("电视没有确认配对，请重新尝试");
            preferences().edit()
                    .putString("tv_host", pendingHost)
                    .putString("paired_host", pendingHost)
                    .putString("server_cert_sha256", fingerprint(pairingPeer))
                    .apply();
        } finally {
            discardPairing();
        }
    }

    void discardPairing() {
        if (pairingSocket != null) {
            try { pairingSocket.close(); } catch (IOException ignored) {}
        }
        pairingSocket = null;
        pairingPeer = null;
        pendingHost = null;
    }

    /** Sends a single app-link request; success means it was transmitted, not that app opened. */
    void launch(String host, String appLink) throws Exception {
        if (appLink == null || appLink.trim().isEmpty()) throw new IOException("应用启动地址不能为空");
        Connection conn = connect(host, REMOTE_PORT);
        try {
            InputStream in = conn.socket.getInputStream();
            OutputStream out = conn.socket.getOutputStream();
            boolean isReady = false;
            for (int i = 0; i < 25; i++) {
                Proto.Message response = Proto.receive(in);
                if (response.has(1)) {
                    Proto.Writer capabilities = new Proto.Writer()
                            .number(1, 611)
                            .message(2, new Proto.Writer().number(3, 1)
                                    .string(4, "1").string(5, "TV Quick Launch Duo").string(6, "1.0"));
                    Proto.send(out, new Proto.Writer().message(1, capabilities));
                } else if (response.has(2)) {
                    Proto.send(out, new Proto.Writer().message(2, new Proto.Writer().number(1, 611)));
                } else if (response.has(8)) {
                    answerPing(out, response);
                } else if (response.has(40)) {
                    isReady = true;
                    break;
                }
            }
            if (!isReady) throw new IOException("电视遥控服务没有完成连接");
            Proto.send(out, new Proto.Writer().message(90, new Proto.Writer().string(1, appLink)));
            // Briefly keep the TLS session open so the TV can process the request.
            long until = System.currentTimeMillis() + 1250;
            conn.socket.setSoTimeout(350);
            while (System.currentTimeMillis() < until) {
                try {
                    Proto.Message response = Proto.receive(in);
                    if (response.has(8)) answerPing(out, response);
                } catch (java.net.SocketTimeoutException timeout) {
                    // No ping needed during this very short session.
                } catch (java.io.EOFException closed) {
                    break;
                }
            }
        } finally {
            conn.socket.close();
        }
    }

    private static void answerPing(OutputStream out, Proto.Message message) throws IOException {
        long ping = message.nested(8).number(1, 0);
        Proto.send(out, new Proto.Writer().message(9, new Proto.Writer().number(1, ping)));
    }
}
