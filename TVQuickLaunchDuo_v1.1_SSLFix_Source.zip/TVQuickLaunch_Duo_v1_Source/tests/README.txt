无需 Android SDK，先检查纯 Java 协议类/配对证书：

javac -d /tmp/tvduo_test app/src/main/java/com/tvquicklaunch/duo/ClientIdentity.java tests/ClientIdentitySmokeTest.java
java -cp /tmp/tvduo_test com.tvquicklaunch.duo.ClientIdentitySmokeTest

其他 Proto 单元测试：请参阅 ProtoSmokeTest.java。
实际 SSL/TLS 配对必须在手机+Google TV 上进行验证。
