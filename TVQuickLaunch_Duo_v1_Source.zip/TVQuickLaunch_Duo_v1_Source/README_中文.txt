TV Quick Launch Duo / TV 双快捷 v1.0
===================================

手机端轻量 Android App（仅 Kodi + Tidal 两个快捷按钮）。
完全独立于 Custom Remote；Google TV 上无需安装配套 APK。

首次使用：
1. 手机和 Google TV 连接同一个局域网，电视已打开。
2. 打开手机上的「TV 双快捷」，点击搜索电视，或手动填入电视 LAN IP。
3. 点击「开始电视配对」，等待电视屏幕显示 6 位十六进制配对码。
4. 输入配对码，点击确认；以后只需打开本 App，点击 Kodi 或 Tidal。

技术：
- Android TV Remote v2 协议，TLS 配对端口 6467，控制端口 6466。
- 使用 Android Keystore 生成每台手机独立的 2048 位 RSA 配对身份，不在 ZIP 里预置私钥。
- 配对成功后，在本机保存电视的证书 SHA-256 指纹和 IP，以防连接冒名设备。
- mDNS 自动发现 _androidtvremote2._tcp.；也可手动输入 IP。
- 纯 Java + Android 原生控件，无第三方运行时依赖。
- 仅用于局域网，不需要注册、账号或互联网服务。

默认启动链接：
Kodi:  market://launch?id=org.xbmc.kodi
Tidal: market://launch?id=com.aspiro.tidal

注意：部分 2026 年版本的 Google Play Store / Android TV Remote Service 可能
不再正确处理 market://launch 链接。该情况会出现「请求已发送但电视没有打开 App」。
这不是配对必然失败，而是电视侧对应用启动链接的兼容性限制。
App 内「连接设置 -> 调整 Kodi / Tidal 启动链接」可自由修改地址。
若电视版 Kodi 已支持 kodi://launch 深度链接，可将 Kodi 改成该地址。

编译环境：
JDK 17 + Android SDK Platform 35 + Gradle 8.7 + Android Gradle Plugin 8.6.1。
使用 Android Studio 打开项目根目录，执行 Build > Build APK(s)。
或在已配置 Android SDK 和 Gradle 8.7 的环境运行：
    gradle :app:assembleDebug
APK 位于 app/build/outputs/apk/debug/app-debug.apk

也提供 GitHub Actions 自动编译：
1. 在 GitHub 新建仓库，把 ZIP 中的目录内容上传到仓库根目录（保留 .github/workflows）。
2. 打开 Actions -> Build TV Quick Launch Duo APK -> Run workflow。
3. 在对应 workflow run 的 Artifacts 下载 TVQuickLaunchDuo-debug-apk，解压得到 APK。

本包是 Android Studio 源代码工程 ZIP，不是可直接安装的 APK。
当前生成环境未安装 Android SDK，因此未执行真机编译或连接电视实测。
建议先测试配对，再分别测试 Kodi 和 Tidal 的链接兼容性。
