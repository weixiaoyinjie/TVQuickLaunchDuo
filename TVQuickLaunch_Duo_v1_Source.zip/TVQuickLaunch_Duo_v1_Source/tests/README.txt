The Android SDK and Google TV are needed for an actual device-level test.
Proto.java is Android-independent and can be tested using JDK's javac.
