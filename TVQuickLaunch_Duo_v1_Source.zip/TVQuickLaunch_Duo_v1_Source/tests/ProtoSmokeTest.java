package com.tvquicklaunch.duo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/** Executable JDK-only checks for protobuf framing and remote app launch field. */
public final class ProtoSmokeTest {
    public static void main(String[] args) throws Exception {
        String url = "market://launch?id=org.xbmc.kodi";
        Proto.Writer link = new Proto.Writer().message(90, new Proto.Writer().string(1, url));
        byte[] packet = link.data();
        Proto.Message outer = Proto.decode(packet);
        if (!outer.has(90)) throw new AssertionError("Missing app launch field");
        byte[] longFrame = new byte[320];
        for (int i = 0; i < longFrame.length; i++) longFrame[i] = (byte) (i % 251);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Proto.send(out, new Proto.Writer().bytes(9, longFrame));
        Proto.Message decoded = Proto.receive(new ByteArrayInputStream(out.toByteArray()));
        if (!decoded.has(9)) throw new AssertionError("Framing failed");
        if (!Arrays.equals(packet, Proto.decode(packet).has(90) ? link.data() : new byte[0]))
            throw new AssertionError("Round-trip failed");
        System.out.println("PASS protobuf nested messages and multi-byte frame lengths");
    }
}
