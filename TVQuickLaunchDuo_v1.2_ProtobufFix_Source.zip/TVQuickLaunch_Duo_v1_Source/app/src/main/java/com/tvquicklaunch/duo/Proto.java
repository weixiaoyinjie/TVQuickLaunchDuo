package com.tvquicklaunch.duo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Minimal protobuf wire codec for the few Google TV Remote v2 messages we need. */
final class Proto {
    private Proto() {}

    static final class Writer {
        private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        Writer number(int field, long value) {
            putVarint(buffer, (field << 3));
            putVarint(buffer, value);
            return this;
        }
        Writer bytes(int field, byte[] payload) {
            putVarint(buffer, (field << 3) | 2);
            putVarint(buffer, payload.length);
            buffer.write(payload, 0, payload.length);
            return this;
        }
        Writer string(int field, String text) {
            return bytes(field, text.getBytes(StandardCharsets.UTF_8));
        }
        Writer message(int field, Writer inner) { return bytes(field, inner.data()); }
        byte[] data() { return buffer.toByteArray(); }
    }

    static final class Message {
        private final Map<Integer, List<Object>> fields = new HashMap<>();
        boolean has(int field) { return fields.containsKey(field); }
        long number(int field, long fallback) {
            Object result = first(field);
            return result instanceof Long ? (Long) result : fallback;
        }
        Message nested(int field) throws IOException {
            Object result = first(field);
            return result instanceof byte[] ? decode((byte[]) result) : new Message();
        }
        private Object first(int field) {
            List<Object> values = fields.get(field);
            return values == null || values.isEmpty() ? null : values.get(0);
        }
        void add(int field, Object value) {
            List<Object> values = fields.get(field);
            if (values == null) { values = new ArrayList<>(); fields.put(field, values); }
            values.add(value);
        }
    }

    static Message decode(byte[] data) throws IOException {
        ByteArrayInputStream input = new ByteArrayInputStream(data);
        Message decoded = new Message();
        while (input.available() > 0) {
            long tag = getVarint(input);
            int field = (int) (tag >>> 3);
            int wire = (int) (tag & 7);
            if (field == 0) throw new IOException("Invalid protobuf field zero");
            if (wire == 0) decoded.add(field, getVarint(input));
            else if (wire == 2) {
                int size = (int) getVarint(input);
                if (size < 0 || size > 1024 * 1024 || size > input.available())
                    throw new IOException("Invalid protobuf payload length");
                // A length-delimited protobuf field is allowed to be empty.
                // ByteArrayInputStream.read(byte[0]) returns -1 at EOF (not 0),
                // so the old read(payload) check rejected legitimate empty
                // pairing acknowledgements (e.g. field 11 / field 31).
                byte[] payload = new byte[size];
                int offset = 0;
                while (offset < size) {
                    int count = input.read(payload, offset, size - offset);
                    if (count < 0) throw new EOFException("Incomplete protobuf");
                    if (count == 0) continue;
                    offset += count;
                }
                decoded.add(field, payload);
            } else if (wire == 1) skip(input, 8);
            else if (wire == 5) skip(input, 4);
            else throw new IOException("Unknown protobuf wire type " + wire);
        }
        return decoded;
    }

    private static void skip(InputStream input, int size) throws IOException {
        for (int i = 0; i < size; i++) if (input.read() < 0) throw new EOFException();
    }

    static void send(OutputStream stream, Writer writer) throws IOException {
        byte[] body = writer.data();
        putVarint(stream, body.length);
        stream.write(body);
        stream.flush();
    }

    static Message receive(InputStream stream) throws IOException {
        long size = getVarint(stream);
        if (size < 0 || size > 1024 * 1024) throw new IOException("Invalid TV frame size " + size);
        byte[] data = new byte[(int) size];
        int offset = 0;
        while (offset < data.length) {
            int count = stream.read(data, offset, data.length - offset);
            if (count < 0) throw new EOFException("TV disconnected");
            offset += count;
        }
        return decode(data);
    }

    private static void putVarint(OutputStream stream, long value) {
        try {
            while (true) {
                int next = (int) (value & 0x7f);
                value >>>= 7;
                if (value == 0) { stream.write(next); break; }
                stream.write(next | 0x80);
            }
        } catch (IOException impossibleForMemoryStream) {
            throw new IllegalStateException(impossibleForMemoryStream);
        }
    }

    private static long getVarint(InputStream stream) throws IOException {
        long result = 0;
        for (int shift = 0; shift <= 63; shift += 7) {
            int b = stream.read();
            if (b < 0) throw new EOFException("Incomplete varint");
            result |= (long) (b & 0x7f) << shift;
            if ((b & 0x80) == 0) return result;
        }
        throw new IOException("Varint exceeds 64 bits");
    }
}
