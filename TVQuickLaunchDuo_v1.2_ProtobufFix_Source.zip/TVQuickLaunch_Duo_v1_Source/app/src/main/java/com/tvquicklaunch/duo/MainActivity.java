package com.tvquicklaunch.duo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Small native Android screen: just two TV app tiles, plus one-time pairing settings. */
public class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(11, 16, 28);
    private static final int SURFACE = Color.rgb(24, 32, 49);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(151, 165, 187);
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TvProtocol protocol;
    private TextView statusText;
    private Button kodiTile, tidalTile;
    private SharedPreferences preferences;
    private volatile boolean runningTask;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private WifiManager.MulticastLock multicastLock;
    private final Map<String, String> discovered = new LinkedHashMap<>();

    private int dp(float amount) { return (int) (getResources().getDisplayMetrics().density * amount + 0.5f); }

    private GradientDrawable background(int color, int borderColor, int radius) {
        GradientDrawable result = new GradientDrawable();
        result.setColor(color);
        result.setCornerRadius(dp(radius));
        if (borderColor != 0) result.setStroke(dp(1), borderColor);
        return result;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void spacing(LinearLayout parent, int height) {
        View spacer = new View(this);
        parent.addView(spacer, new LinearLayout.LayoutParams(1, dp(height)));
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        preferences = getSharedPreferences("tv_settings", MODE_PRIVATE);
        protocol = new TvProtocol(this);
        buildUi();
        if (!isPaired()) handler.postDelayed(this::settingsDialog, 300);
    }

    private boolean isPaired() {
        String host = preferences.getString("tv_host", "");
        return !host.isEmpty() && host.equals(preferences.getString("paired_host", ""))
                && !preferences.getString("server_cert_sha256", "").isEmpty();
    }

    private void refreshStatus() {
        statusText.setText(isPaired()
                ? "● 已配对  ·  " + preferences.getString("tv_host", "")
                : "○ 未配对 Google TV  ·  点击设置连接");
    }

    private void buildUi() {
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        getWindow().getDecorView().setSystemUiVisibility(0);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout body = vertical();
        body.setPadding(dp(22), dp(34), dp(22), dp(24));
        scroll.addView(body);
        setContentView(scroll);

        TextView eyebrow = text("GOOGLE TV  ·  QUICK LAUNCH", 11, Color.rgb(78, 178, 236), true);
        eyebrow.setLetterSpacing(0.10f);
        body.addView(eyebrow);
        spacing(body, 14);
        body.addView(text("电视快捷启动", 29, WHITE, true));
        spacing(body, 7);
        body.addView(text("打开 App，选择电视上的应用。", 14, MUTED, false));
        spacing(body, 20);

        LinearLayout statusPanel = vertical();
        statusPanel.setPadding(dp(13), dp(13), dp(13), dp(13));
        statusPanel.setBackground(background(SURFACE, Color.rgb(45, 58, 79), 16));
        statusText = text("", 13, Color.rgb(199, 215, 229), false);
        statusPanel.addView(statusText);
        body.addView(statusPanel);
        refreshStatus();
        spacing(body, 27);

        TextView section = text("选择要在电视上打开的应用", 14, MUTED, true);
        body.addView(section);
        spacing(body, 14);
        kodiTile = tile(body, "KODI", "影视 · 媒体中心", "K", 0xFF117CBF);
        spacing(body, 13);
        tidalTile = tile(body, "TIDAL", "音乐 · HiFi 播放", "◆", 0xFF343C50);
        spacing(body, 24);
        Button settings = new Button(this);
        settings.setAllCaps(false);
        settings.setText("⚙  电视连接与配对设置");
        settings.setTextSize(14);
        settings.setTextColor(WHITE);
        settings.setBackground(background(0xFF263149, 0, 15));
        settings.setMinHeight(dp(52));
        settings.setOnClickListener(v -> settingsDialog());
        body.addView(settings, new LinearLayout.LayoutParams(-1, dp(54)));
        spacing(body, 20);
        TextView hint = text("仅使用家庭局域网。手机和 Google TV 必须互通。\n不需要在电视安装额外 App。", 12, MUTED, false);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(dp(4), 1f);
        body.addView(hint);
    }

    private Button tile(LinearLayout body, String label, String subtitle, String icon, int accent) {
        // A single large button is more accessible than nested touch targets.
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(icon + "   " + label + "\n       " + subtitle);
        button.setTextSize(19);
        button.setTextColor(WHITE);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(dp(23), 0, dp(18), 0);
        button.setBackground(background(accent, 0, 23));
        body.addView(button, new LinearLayout.LayoutParams(-1, dp(122)));
        button.setOnClickListener(v -> launchApp(label));
        return button;
    }

    private void launchApp(String app) {
        if (runningTask) return;
        if (!isPaired()) {
            Toast.makeText(this, "请先连接并配对 Google TV", Toast.LENGTH_SHORT).show();
            settingsDialog();
            return;
        }
        final String host = preferences.getString("tv_host", "");
        final String link = preferences.getString("link_" + app.toLowerCase(),
                app.equals("KODI") ? "market://launch?id=org.xbmc.kodi"
                                   : "market://launch?id=com.aspiro.tidal");
        runningTask = true;
        kodiTile.setEnabled(false);
        tidalTile.setEnabled(false);
        statusText.setText("正在连接电视，发送 " + app + " 启动指令…");
        worker.execute(() -> {
            try {
                protocol.launch(host, link);
                ui(() -> {
                    statusText.setText("✓ " + app + " 启动指令已发送至电视");
                    Toast.makeText(this, "已发送 " + app + " 启动请求，请检查电视画面", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception ex) {
                ui(() -> {
                    statusText.setText("连接或启动失败：" + clean(ex));
                    new AlertDialog.Builder(this)
                            .setTitle("未能发送启动指令")
                            .setMessage(clean(ex) + "\n\n请确认电视开机、同一局域网，以及原先配对仍有效。")
                            .setPositiveButton("连接设置", (d, w) -> settingsDialog())
                            .setNegativeButton("关闭", null)
                            .show();
                });
            } finally {
                ui(() -> {
                    runningTask = false;
                    kodiTile.setEnabled(true);
                    tidalTile.setEnabled(true);
                });
            }
        });
    }

    private String clean(Exception error) {
        String msg = error.getMessage();
        return msg != null && !msg.isEmpty() ? msg : error.getClass().getSimpleName();
    }

    private void ui(Runnable runnable) { runOnUiThread(() -> { if (!isFinishing() && !isDestroyed()) runnable.run(); }); }

    private void settingsDialog() {
        if (runningTask) return;
        final LinearLayout panel = vertical();
        panel.setPadding(dp(22), dp(6), dp(22), dp(6));
        TextView intro = text("首次使用请搜索电视，或输入电视局域网 IP。配对只需完成一次。", 13, 0xFFE0E8F2, false);
        intro.setLineSpacing(dp(3), 1f);
        panel.addView(intro);
        spacing(panel, 15);

        EditText hostInput = new EditText(this);
        hostInput.setSingleLine(true);
        hostInput.setText(preferences.getString("tv_host", ""));
        hostInput.setHint("电视 IP，例如 192.168.1.100");
        hostInput.setTextSize(15);
        hostInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        panel.addView(hostInput, new LinearLayout.LayoutParams(-1, dp(54)));
        spacing(panel, 10);

        Button find = new Button(this);
        find.setAllCaps(false);
        find.setText("搜索局域网 Google TV");
        panel.addView(find, new LinearLayout.LayoutParams(-1, dp(50)));
        spacing(panel, 10);

        Button start = new Button(this);
        start.setAllCaps(false);
        start.setText("开始电视配对");
        panel.addView(start, new LinearLayout.LayoutParams(-1, dp(50)));
        spacing(panel, 8);

        TextView help = text("等待电视显示配对码后，再在下面输入。", 12, 0xFFD2DEEC, false);
        panel.addView(help);
        spacing(panel, 8);
        EditText pin = new EditText(this);
        pin.setSingleLine(true);
        pin.setHint("电视上的 6 位配对码");
        pin.setTextSize(16);
        pin.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        pin.setVisibility(View.GONE);
        panel.addView(pin);

        Button finish = new Button(this);
        finish.setAllCaps(false);
        finish.setText("确认配对码");
        finish.setVisibility(View.GONE);
        panel.addView(finish, new LinearLayout.LayoutParams(-1, dp(50)));
        spacing(panel, 8);

        TextView pairingStatus = text(isPaired() ? "当前已配对，可直接关闭设置" : "尚未配对", 12, 0xFFD2DEEC, false);
        panel.addView(pairingStatus);
        spacing(panel, 15);
        TextView advanced = text("高级：若电视收到指令却无法打开应用，可调整启动链接。", 12, 0xFFD2DEEC, false);
        panel.addView(advanced);
        Button linkSetting = new Button(this);
        linkSetting.setAllCaps(false);
        linkSetting.setText("调整 Kodi / Tidal 启动链接");
        panel.addView(linkSetting, new LinearLayout.LayoutParams(-1, dp(48)));

        ScrollView scrolling = new ScrollView(this);
        scrolling.addView(panel);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("连接 Google TV")
                .setView(scrolling)
                .setNegativeButton("关闭", (d, w) -> { stopDiscovery(); protocol.discardPairing(); })
                .create();
        dialog.setOnDismissListener(d -> { stopDiscovery(); protocol.discardPairing(); });
        dialog.show();
        linkSetting.setOnClickListener(v -> advancedLinks());

        find.setOnClickListener(v -> {
            pairingStatus.setText("正在搜索电视，约需数秒…");
            startDiscovery(hostInput, pairingStatus);
        });

        start.setOnClickListener(v -> {
            String host = hostInput.getText().toString().trim();
            if (host.isEmpty() || host.contains("/") || host.contains(" ") || host.contains(":")) {
                hostInput.setError("请输入正确的 IPv4 地址或主机名");
                return;
            }
            stopDiscovery();
            start.setEnabled(false);
            pairingStatus.setText("正在连接电视配对端口 6467…");
            worker.execute(() -> {
                try {
                    protocol.beginPairing(host);
                    ui(() -> {
                        pairingStatus.setText("电视应该已显示配对码，请输入下方 6 位字符");
                        pin.setVisibility(View.VISIBLE);
                        finish.setVisibility(View.VISIBLE);
                        start.setEnabled(true);
                        pin.requestFocus();
                    });
                } catch (Exception err) {
                    ui(() -> {
                        pairingStatus.setText("连接失败：" + clean(err));
                        start.setEnabled(true);
                    });
                }
            });
        });

        finish.setOnClickListener(v -> {
            String text = pin.getText().toString().trim();
            finish.setEnabled(false);
            pairingStatus.setText("正在验证配对码…");
            worker.execute(() -> {
                try {
                    protocol.completePairing(text);
                    ui(() -> {
                        pairingStatus.setText("配对成功！以后打开 App 即可使用。");
                        refreshStatus();
                        dialog.dismiss();
                        Toast.makeText(this, "Google TV 配对完成", Toast.LENGTH_SHORT).show();
                    });
                } catch (IllegalArgumentException badCode) {
                    ui(() -> {
                        pairingStatus.setText(clean(badCode));
                        finish.setEnabled(true);
                    });
                } catch (Exception err) {
                    ui(() -> {
                        pairingStatus.setText("配对失败：" + clean(err) + "，请重新开始配对");
                        start.setEnabled(true);
                        finish.setEnabled(false);
                    });
                }
            });
        });
    }

    private void advancedLinks() {
        String defaultKodi = "market://launch?id=org.xbmc.kodi";
        String defaultTidal = "market://launch?id=com.aspiro.tidal";
        LinearLayout body = vertical();
        body.setPadding(dp(22), dp(9), dp(22), 0);
        body.addView(text("Kodi 应用启动链接", 13, 0xFFD2DEEC, false));
        EditText kodi = new EditText(this);
        kodi.setSingleLine(true);
        kodi.setTextSize(13);
        kodi.setText(preferences.getString("link_kodi", defaultKodi));
        body.addView(kodi);
        spacing(body, 13);
        body.addView(text("Tidal 应用启动链接", 13, 0xFFD2DEEC, false));
        EditText tidal = new EditText(this);
        tidal.setSingleLine(true);
        tidal.setTextSize(13);
        tidal.setText(preferences.getString("link_tidal", defaultTidal));
        body.addView(tidal);
        spacing(body, 9);
        body.addView(text("部分新版 Google Play 服务不再响应 market://launch。Kodi 若支持新版深度链接，可尝试 kodi://launch。", 12, 0xFFD2DEEC, false));
        new AlertDialog.Builder(this).setTitle("应用启动地址").setView(body)
                .setPositiveButton("保存", (d, w) -> {
                    preferences.edit().putString("link_kodi", kodi.getText().toString().trim())
                            .putString("link_tidal", tidal.getText().toString().trim()).apply();
                    Toast.makeText(this, "启动地址已保存", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("恢复默认", (d, w) -> preferences.edit()
                        .remove("link_kodi").remove("link_tidal").apply())
                .setNegativeButton("取消", null).show();
    }

    private void startDiscovery(EditText target, TextView info) {
        stopDiscovery();
        discovered.clear();
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            multicastLock = wifi.createMulticastLock("tv-duo-mdns");
            multicastLock.setReferenceCounted(false);
            multicastLock.acquire();
            nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);
            discovery = new NsdManager.DiscoveryListener() {
                @Override public void onStartDiscoveryFailed(String type, int code) { ui(() -> info.setText("搜索启动失败：" + code)); stopDiscovery(); }
                @Override public void onStopDiscoveryFailed(String type, int code) { }
                @Override public void onDiscoveryStarted(String type) { }
                @Override public void onDiscoveryStopped(String type) { }
                @Override public void onServiceLost(NsdServiceInfo service) { }
                @Override public void onServiceFound(NsdServiceInfo service) {
                    try {
                        nsd.resolveService(service, new NsdManager.ResolveListener() {
                            @Override public void onResolveFailed(NsdServiceInfo s, int code) { }
                            @Override public void onServiceResolved(NsdServiceInfo resolved) {
                                if (resolved.getHost() == null) return;
                                String ip = resolved.getHost().getHostAddress();
                                if (ip == null || !ip.matches("[0-9.]+")) return;
                                ui(() -> {
                                    discovered.put(ip, resolved.getServiceName());
                                    if (discovered.size() == 1) target.setText(ip);
                                    info.setText("发现 " + discovered.size() + " 台电视，可直接配对");
                                });
                            }
                        });
                    } catch (Exception ignored) { }
                }
            };
            nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, discovery);
            handler.postDelayed(() -> {
                stopDiscovery();
                if (isFinishing()) return;
                if (discovered.isEmpty()) info.setText("未发现电视，请手动输入 Google TV 的局域网 IP");
                else if (discovered.size() > 1) {
                    List<String> ips = new ArrayList<>(discovered.keySet());
                    String[] options = new String[ips.size()];
                    for (int i = 0; i < ips.size(); i++)
                        options[i] = discovered.get(ips.get(i)) + "  ·  " + ips.get(i);
                    new AlertDialog.Builder(this).setTitle("选择电视")
                            .setItems(options, (d, i) -> target.setText(ips.get(i))).show();
                }
            }, 5500);
        } catch (Exception error) {
            info.setText("自动搜索不可用，请直接输入电视 IP：" + clean(error));
            stopDiscovery();
        }
    }

    private void stopDiscovery() {
        if (nsd != null && discovery != null) {
            try { nsd.stopServiceDiscovery(discovery); } catch (Exception ignored) { }
        }
        discovery = null;
        if (multicastLock != null) {
            try { if (multicastLock.isHeld()) multicastLock.release(); } catch (Exception ignored) { }
        }
        multicastLock = null;
    }

    @Override protected void onDestroy() {
        stopDiscovery();
        protocol.discardPairing();
        worker.shutdownNow();
        super.onDestroy();
    }
}
