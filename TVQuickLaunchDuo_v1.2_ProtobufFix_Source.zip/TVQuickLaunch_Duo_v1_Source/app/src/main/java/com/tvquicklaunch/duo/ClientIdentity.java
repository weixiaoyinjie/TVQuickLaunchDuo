package com.tvquicklaunch.duo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Remote-v2 client identity, stored in a private PKCS#12 container.
 *
 * AndroidKeyStore keys restricted to SHA-256/PKCS#1 signing are not a reliable
 * general-purpose TLS client identity across Conscrypt/Google TV versions.
 * Generate a normal RSA pair and self-signed X.509 certificate instead.
 *
 * No external crypto library is needed. The tiny DER encoder below encodes
 * only the standard X.509 structures that this locally generated cert uses.
 * The certificate is verified by the platform's X.509 parser before storage.
 */
final class ClientIdentity {
    private static final String FILE_NAME = "tv_duo_identity_v2.p12";
    private static final String ALIAS = "tvduo-remote";
    private static final char[] PASSWORD = "tvduo-local-identity-v2".toCharArray();

    private ClientIdentity() { }

    static String alias() { return ALIAS; }
    static char[] password() { return PASSWORD.clone(); }

    static synchronized KeyStore loadOrCreate(File filesDir) throws Exception {
        File file = new File(filesDir, FILE_NAME);
        if (file.exists()) {
            // Do NOT silently regenerate on corruption: that would repeatedly
            // invalidate the TV's existing pairing without explaining why.
            try (FileInputStream input = new FileInputStream(file)) {
                KeyStore stored = KeyStore.getInstance("PKCS12");
                stored.load(input, PASSWORD);
                if (stored.getKey(ALIAS, PASSWORD) == null || stored.getCertificate(ALIAS) == null) {
                    throw new IllegalStateException("保存的配对证书不完整");
                }
                return stored;
            }
        }

        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048, new SecureRandom());
        KeyPair keyPair = generator.generateKeyPair();
        X509Certificate certificate = makeCertificate(keyPair);
        KeyStore store = KeyStore.getInstance("PKCS12");
        store.load(null, PASSWORD);
        store.setKeyEntry(ALIAS, keyPair.getPrivate(), PASSWORD, new Certificate[]{certificate});

        File tmp = new File(filesDir, FILE_NAME + ".tmp");
        try (FileOutputStream output = new FileOutputStream(tmp)) {
            store.store(output, PASSWORD);
            output.getFD().sync();
        }
        if (!tmp.renameTo(file)) {
            if (file.exists() && !file.delete()) throw new IllegalStateException("不能保存新的配对证书");
            if (!tmp.renameTo(file)) throw new IllegalStateException("不能保存新的配对证书");
        }
        // Check that Android can read the saved PKCS#12 file on this device.
        try (FileInputStream input = new FileInputStream(file)) {
            KeyStore verified = KeyStore.getInstance("PKCS12");
            verified.load(input, PASSWORD);
            if (verified.getKey(ALIAS, PASSWORD) == null) throw new IllegalStateException("配对证书保存失败");
            return verified;
        }
    }

    private static X509Certificate makeCertificate(KeyPair keys) throws Exception {
        final byte[] sha256WithRsa = Der.sequence(
                Der.oid("1.2.840.113549.1.1.11"), Der.nullValue());
        final byte[] distinguishedName = Der.sequence(
                Der.set(Der.sequence(Der.oid("2.5.4.3"),
                        Der.utf8("TV Quick Launch Duo"))));
        long now = System.currentTimeMillis();
        Date notBefore = new Date(now - 86_400_000L);
        Date notAfter = new Date(now + 10L * 365L * 86_400_000L);
        byte[] extensions = Der.explicit(3, Der.sequence(
                // BasicConstraints: critical, cA=false (empty sequence).
                Der.sequence(Der.oid("2.5.29.19"), Der.bool(true),
                        Der.octets(Der.sequence())),
                // KeyUsage: digitalSignature + keyEncipherment.
                Der.sequence(Der.oid("2.5.29.15"), Der.bool(true),
                        Der.octets(Der.bitString(new byte[]{(byte) 0xA0}, 5)))
        ));
        byte[] tbs = Der.sequence(
                Der.explicit(0, Der.integer(BigInteger.valueOf(2))),
                Der.integer(new BigInteger(120, new SecureRandom()).add(BigInteger.ONE)),
                sha256WithRsa,
                distinguishedName,
                Der.sequence(Der.time(notBefore), Der.time(notAfter)),
                distinguishedName,
                keys.getPublic().getEncoded(),
                extensions
        );
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(keys.getPrivate());
        signature.update(tbs);
        byte[] certBytes = Der.sequence(tbs, sha256WithRsa,
                Der.bitString(signature.sign(), 0));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(certBytes));
        cert.checkValidity();
        cert.verify(keys.getPublic());
        return cert;
    }

    private static final class Der {
        private static byte[] value(int tag, byte[] data) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(tag);
            if (data.length < 128) out.write(data.length);
            else if (data.length < 256) { out.write(0x81); out.write(data.length); }
            else if (data.length < 65536) {
                out.write(0x82); out.write(data.length >>> 8); out.write(data.length & 255);
            } else throw new IllegalArgumentException("DER field too large");
            out.write(data, 0, data.length);
            return out.toByteArray();
        }
        private static byte[] join(byte[]... items) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            for (byte[] item : items) out.write(item, 0, item.length);
            return out.toByteArray();
        }
        static byte[] sequence(byte[]... items) { return value(0x30, join(items)); }
        static byte[] set(byte[]... items) { return value(0x31, join(items)); }
        static byte[] explicit(int tag, byte[] nested) { return value(0xA0 + tag, nested); }
        static byte[] integer(BigInteger number) { return value(0x02, number.toByteArray()); }
        static byte[] utf8(String str) { return value(0x0C, str.getBytes(StandardCharsets.UTF_8)); }
        static byte[] nullValue() { return value(0x05, new byte[0]); }
        static byte[] bool(boolean b) { return value(0x01, new byte[]{(byte)(b ? 0xFF : 0)}); }
        static byte[] octets(byte[] bytes) { return value(0x04, bytes); }
        static byte[] bitString(byte[] bytes, int unusedBits) {
            if (unusedBits < 0 || unusedBits > 7) throw new IllegalArgumentException("bad BIT STRING");
            return value(0x03, join(new byte[]{(byte)unusedBits}, bytes));
        }
        static byte[] oid(String dotted) {
            String[] components = dotted.split("\\.");
            int a = Integer.parseInt(components[0]);
            int b = Integer.parseInt(components[1]);
            if (a > 2 || b < 0 || (a < 2 && b >= 40)) throw new IllegalArgumentException("bad OID");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            writeBase128(bytes, (long)a * 40L + b);
            for (int i = 2; i < components.length; i++) {
                writeBase128(bytes, Long.parseLong(components[i]));
            }
            return value(0x06, bytes.toByteArray());
        }
        private static void writeBase128(ByteArrayOutputStream bytes, long number) {
            if (number < 0) throw new IllegalArgumentException("bad OID component");
            int bits = 0;
            for (long test = number; test >= 128; test >>>= 7) bits += 7;
            for (; bits > 0; bits -= 7) bytes.write((int)((number >>> bits) & 127) | 128);
            bytes.write((int)(number & 127));
        }
        static byte[] time(Date date) {
            SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy", Locale.US);
            yearFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            int year = Integer.parseInt(yearFormat.format(date));
            boolean utc = year >= 1950 && year <= 2049;
            SimpleDateFormat formatter = new SimpleDateFormat(
                    utc ? "yyMMddHHmmss'Z'" : "yyyyMMddHHmmss'Z'", Locale.US);
            formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
            return value(utc ? 0x17 : 0x18,
                    formatter.format(date).getBytes(StandardCharsets.US_ASCII));
        }
    }
}
