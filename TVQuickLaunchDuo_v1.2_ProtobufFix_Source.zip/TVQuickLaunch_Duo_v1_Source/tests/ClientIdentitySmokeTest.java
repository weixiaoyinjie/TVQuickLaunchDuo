package com.tvquicklaunch.duo;
import java.io.File;
import java.nio.file.Files;
import java.security.KeyStore;
import java.security.Key;
import java.security.Signature;
import java.security.cert.X509Certificate;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.TrustManager;
import java.security.SecureRandom;
public class ClientIdentitySmokeTest {
    public static void main(String[] args) throws Exception {
        File dir=Files.createTempDirectory("tv-duo-id").toFile();
        KeyStore one=ClientIdentity.loadOrCreate(dir);
        KeyStore two=ClientIdentity.loadOrCreate(dir);
        X509Certificate cert=(X509Certificate)one.getCertificate(ClientIdentity.alias());
        cert.verify(cert.getPublicKey());
        if(!java.util.Arrays.equals(cert.getEncoded(),two.getCertificate(ClientIdentity.alias()).getEncoded()))throw new AssertionError("identity changed");
        if(cert.getBasicConstraints()!=-1)throw new AssertionError("cert marked CA");
        KeyManagerFactory km=KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        km.init(one,ClientIdentity.password());
        SSLContext tls=SSLContext.getInstance("TLS");
        tls.init(km.getKeyManagers(), new TrustManager[]{new X509TrustManager() {
          public void checkClientTrusted(X509Certificate[] c, String a){}
          public void checkServerTrusted(X509Certificate[] c,String a){}
          public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
        }},new SecureRandom());
        System.out.println("OK: certificate subject="+cert.getSubjectX500Principal()+", keyUsage="+java.util.Arrays.toString(cert.getKeyUsage())+", tls="+tls.getProtocol()+", bytes="+dir.listFiles()[0].length());
    }
}
