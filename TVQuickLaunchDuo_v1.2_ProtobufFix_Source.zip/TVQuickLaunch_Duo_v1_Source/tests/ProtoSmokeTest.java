package com.tvquicklaunch.duo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/** Executable JDK-only checks for protobuf framing and remote app launch field. */
public final class ProtoSmokeTest {
    public static void main(String[] args) throws Exception {
        // Reproduces v1.1 crash: a pairing ACK is a valid zero-length nested
        // message. At end-of-buffer ByteArrayInputStream.read(byte[0]) is -1.
        byte[] emptyAck = new byte[]{(byte) 0x5A, 0x00}; // field 11, len=0
        Proto.Message ack = Proto.decode(emptyAck);
        if (!ack.has(11) || ack.nested(11).has(1))
            throw new AssertionError("Empty pairing ACK must decode cleanly");
        byte[] emptyConfigAck = new byte[]{(byte) 0xFA, 0x01, 0x00}; // field 31, len=0
        Proto.Message configAck = Proto.decode(emptyConfigAck);
        if (!configAck.has(31)) throw new AssertionError("Missing empty config ACK");
        Proto.Message midPacket = Proto.decode(new byte[]{(byte) 0x5A, 0x00, 0x10, (byte) 0xC8, 0x01});
        if (!midPacket.has(11) || midPacket.number(2, -1) != 200)
            throw new AssertionError("Empty field followed by status must decode");
        ByteArrayOutputStream framedAck = new ByteArrayOutputStream();
        Proto.send(framedAck, new Proto.Writer().message(11, new Proto.Writer()));
        if (!Proto.receive(new ByteArrayInputStream(framedAck.toByteArray())).has(11))
            throw new AssertionError("Framed empty ACK must decode");

        String url = "market://launch?id=org.xbmc.kodi";
        Proto.Writer link = new Proto.Writer().message(90, new Proto.Writer().string(1, url));
        byte[] packet = link.data();
        Proto.Message outer = Proto.decode(packet);
        if (!outer.has(90)) throw new AssertionError("Missing app launch field");
        byte[] longFrame = new byte[320];
        for (int i = 0; i < longFrame.length; i++) longFrame[i] = (byte) (i % 251);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Proto.send(out, new Proto.Writer().bytes(9, longFrame));
        Proto.Message decoded = Proto.receive(new ByteArrayInputStream(out.toByteArray()));
        if (!decoded.has(9)) throw new AssertionError("Framing failed");
        if (!Arrays.equals(packet, Proto.decode(packet).has(90) ? link.data() : new byte[0]))
            throw new AssertionError("Round-trip failed");
        System.out.println("PASS protobuf zero-length pairing acknowledgements, nested messages, and multi-byte frame lengths");
    }
}
